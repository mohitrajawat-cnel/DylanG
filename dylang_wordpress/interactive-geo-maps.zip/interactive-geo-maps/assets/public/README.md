# igm-public-assets
Public assets for the Interactive Geo Maps project
